require.config({
    paths: {
        jquery: 'lib/jquery-1.10.2.min',
        underscore: 'lib/underscore-min',
        backbone: 'lib/backbone-min'
    },
    waitSeconds: 0
});

require([
  'jquery',     // lib/jquery/jquery
  'underscore', // lib/underscore/underscore
  'backbone',    // lib/backbone/backbone
  'app'
], function($, _, Backbone, app){
    alert(1);
    app.init();
});