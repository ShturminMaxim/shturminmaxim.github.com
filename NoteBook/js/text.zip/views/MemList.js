define([
  'jquery',     // lib/jquery/jquery
  'lib/underscore-min', // lib/underscore/underscore
  'lib/backbone-min',    // lib/backbone/backbone
  'collections/MemsCollection',
  'text!template/main.html' // get our templates like a text
], function($, _, Backbone, MemCollection, mainTemplate){
       var MemView = Backbone.View.extend({
           el:$(".container"),
           initialize:function(){
                this.collection = new MemCollection();
                this.collection.add({});

                var compiledTemplate = _.template(mainTemplate, { mems : this.collection.models });

                this.$el.append(compiledTemplate);
           }
       })
  return MemView;
});