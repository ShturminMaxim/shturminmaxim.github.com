define([
  'jquery',     // lib/jquery/jquery
  'lib/underscore-min', // lib/underscore/underscore
  'lib/backbone-min',    // lib/backbone/backbone
  '../models/MemModel'
], function($, _, Backbone, MemModel){
    console.log('collection - '+Backbone);
  var MemCollection = Backbone.Collection.extend({
      model:MemModel
  });

  return MemCollection;
});