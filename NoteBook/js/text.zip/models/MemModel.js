define([
  'lib/underscore-min', // lib/underscore/underscore
  'lib/backbone-min'    // lib/backbone/backbone
], function(_, Backbone){

    console.log('model - '+require('backbone'));
    var MemModel = Backbone.Model.extend({
        defaults: {
            task : 'regular',
            client: '',
            activity : '',
            time: '',
            link : '',
            date : ''
        }
    })

  return MemModel;
});